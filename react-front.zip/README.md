# nails-spa front creation


npx create-react-app react-front

# frontend


npm i


npm start

# backend 
npm i json-server


npm i


npm start


nodemon app
