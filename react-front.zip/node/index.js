// Set options as a parameter, environment variable, or rc file.
// eslint-disable-next-line no-global-assign
module.exports = require("./main.js")
